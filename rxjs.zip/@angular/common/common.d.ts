/**
 * Generated bundle index. Do not edit.
 */
export * from './index';
export { COMMON_DIRECTIVES as ɵangular_packages_common_common_e } from './src/directives/index';
export { LocaleDataIndex as ɵangular_packages_common_common_c } from './src/i18n/locale_data';
export { findLocaleData as ɵangular_packages_common_common_d } from './src/i18n/locale_data_api';
export { DEPRECATED_PLURAL_FN as ɵangular_packages_common_common_a, getPluralCase as ɵangular_packages_common_common_b } from './src/i18n/localization';
export { COMMON_DEPRECATED_I18N_PIPES as ɵangular_packages_common_common_g } from './src/pipes/deprecated/index';
export { COMMON_PIPES as ɵangular_packages_common_common_f } from './src/pipes/index';
