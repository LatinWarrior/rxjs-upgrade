/**
 * @license Angular v7.2.7
 * (c) 2010-2019 Google LLC. https://angular.io/
 * License: MIT
 */

export * from './browser/browser';
